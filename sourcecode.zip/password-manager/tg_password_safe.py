from tkinter import *
import random

YELLOW = "#f7f5dd"
FONT_NAME = "Courier"


# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def generate_password():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
               't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
               'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    password = []

    for letter in range(0, 5):
        password.append(random.choice(letters))

    for number in range(0, 3):
        password.append(random.choice(numbers))

    for symbol in range(0, 3):
        password.append(random.choice(symbols))

    random.shuffle(password)
    final_password = ""

    for character in password:
        final_password += character

    password_entry.insert(0, final_password)


# ---------------------------- SAVE PASSWORD ------------------------------- #
def add():
    WEBSITE = website_entry.get()
    USERNAME = username_entry.get()
    PASSWORD = password_entry.get()
    with open("data.txt", "a") as file:
        file.write(f"{WEBSITE} | {USERNAME} | {PASSWORD} \n")
    website_entry.delete(0, "end")
    username_entry.delete(0, "end")
    password_entry.delete(0, "end")


# ---------------------------- UI SETUP ------------------------------- #

window = Tk()
window.title("TG Password Manager")
window.config(padx=50, pady=50, bg="#ffffff")

canvas = Canvas(width=200, height=200, bg="#ffffff", highlightthickness=0)
logo_image = PhotoImage(file="logo.png")
canvas.create_image(100, 100, image=logo_image)
canvas.grid(row=0, column=1, columnspan=2)

# Label--------------------------------------------------------------------

website_label = Label(text="Website", bg="#ffffff", font=(FONT_NAME, 12), fg="blue")
website_label.grid(row=1, column=0)

username_label = Label(text="User Name/Email", bg="#ffffff", font=(FONT_NAME, 12), fg="blue")
username_label.grid(row=2, column=0)

password_label = Label(text="Password", bg="#ffffff", font=(FONT_NAME, 12), fg="blue")
password_label.grid(row=3, column=0)

# Buttons--------------------------------------------------------------------

add_button = Button(text="Add", width=51, command=add)
add_button.grid(row=5, column=1, columnspan=3)

generate_button = Button(text="Generate Password", width=20, height=1, command=generate_password)
generate_button.grid(row=3, column=3, columnspan=2)

# Entry--------------------------------------------------------------------
website_entry = Entry(width=60)
website_entry.grid(row=1, column=1, columnspan=3)
website_entry.focus()

username_entry = Entry(width=60)
username_entry.grid(row=2, column=1, columnspan=3)

password_entry = Entry(width=35)
password_entry.grid(row=3, column=1, columnspan=2)

mainloop()
